--
-- $Id$
--
--多加几行中文给enca认识这是中文
--多加几行中文给enca认识这是中文
--多加几行中文给enca认识这是中文

local saconfigFile = nil
local configFile = nil
local serverName = ""
function GetServerType()
	return serverName
end

function parseCommonArguments()
	for i=1, #arg do
		if arg[i] == '-config' then
			assert(i+1 <= #arg)
			configFile = arg[i+1]
			i = i + 1
		elseif arg[i] == '-saconfig' then
			assert(i+1 <= #arg)
			saconfigFile = arg[i+1]
			i = i + 1
		elseif arg[i] == '-n' then
			assert(i+1 <= #arg)
			serverName = arg[i+1]
			i = i + 1
		end
	end

	configFile = configFile or serverName
	saconfigFile = saconfigFile or "SAConfig"
end

function checkServerDependency()
	
end

function SetupRequirePath()
	local serverName = serverName
	
	local pathMgr = GetPathMgr()
	--replayer要读取gas一部分lua文件
	if (serverName == 'replayer') then
		szPath = string.format("../design/data/Server/?.lua;../design/data/Common/?.lua;game/%s/lua/?.lua;game/gas/lua/?.lua;game/common/lua/?.lua;game/server_common/lua/?.lua;game/common/lua/test/?.lua;engine/lua/?.lua;etc/gas/?.lua;", serverName)
	else
		szPath = string.format("../design/data/Server/?.lua;../design/data/Common/?.lua;game/%s/lua/?.lua;game/common/lua/?.lua;game/server_common/lua/?.lua;game/common/lua/test/?.lua;engine/lua/?.lua;etc/gas/?.lua;", serverName)
	end
	print(szPath)
	
	local szScriptPath = ""
	local pathTbl = {}
	for szTok in string.gmatch(szPath, "([^;]+)") do
		pathMgr:SetCurPath(szTok)
		table.insert(pathTbl, pathMgr:GetCurPath())
	end
	szScriptPath = table.concat(pathTbl, ";")
	ArkScriptSetSearchPath(szScriptPath)
	g_sSettingPath = pathMgr:GetRootPath()
	
	pathMgr:SetCurPath("../artist/res")
	Chdir(pathMgr:GetCurPath())	
	
	print("current path", pathMgr:GetCurPath())	

	require(saconfigFile)
	require("SAServerInfo")
	
	LuaCleanUpTempMapFiles()
	LuaLogInit(SAConfig.SERVER_GROUP_ID or 0)
	
	AsyncFlowSetup()	
end

function SetupServerEnvironment()
	parseCommonArguments()
	SetupRequirePath()
	
	require(configFile)
	require("StringLocalization")
	require("common/ArkScript")
	require("server/ArkCoreServer")
	require("common/LuaDump")
	
	--check jit or not
	if package.loaded.jit then
		print( "Using JIT" )
	else
		print( "Not Using JIT" )
	end

	local netThreadNum = 1
	if GetServerType() == "gateway" and rawget(_G, "GATEWAY_MULTI_THREAD") then
		netThreadNum = SAConfig.GatewayNetThreadNum or 1
	end

	CNetworkMgr.StartUp(false, netThreadNum)
	RegisterAppServerNetworkEvent()
end

function CleanupServerEnvironment()
	CNetworkMgr.ShutDown()
	UnRegisterAppServerNetworkEvent()
end

	
