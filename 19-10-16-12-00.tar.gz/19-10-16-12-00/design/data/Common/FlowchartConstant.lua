EFlowEvent =
{   
    Start = 1,
    See = 2,
    Bye = 3,
    ClientSee = 4,
    ClientBye = 5,
    Attack = 6,
    Kill = 7,
    EnterSafeRegion = 8,
    LeaveSafeRegion = 9,
    AttackObjectDie = 10,
    DummyPlayerReborn = 11,
    BossCastDangerSkill = 12,
    Tick = 13,
    MoveEnded = 14,
    AboutToMoveEnd = 15,
    MoveStopped = 16,
    MoveBegan = 17,
    PickSuccess = 18,
    TargetMove = 19,
    TaskInfoUpdate = 20,
    UpdateGameplayJob = 21,
    ThreatenUpdate = 22,
    SZQXBossAllDie = 23,
    EnterFight = 24,
    LeaveFight = 25,
    LeaveHitRecover = 26,
    EnterDash = 27,
    LeaveDash = 28,
    RecoverFromCast = 29,
    ChangePetMode = 30,
    BeginRouteEscort = 31,
    ReachLastWayPoint = 32,
    ReachWayPoint = 33,
    UnderAttack = 34,
    Die = 35,
    AlmostDie = 36,
    MonsterInClusterDestroy = 37,
    MonsterDie = 38,
    TeamVoteSuccess = 39,
    CharacterEnterRegion = 40,
    CharacterLeaveRegion = 41,
    EnterRegion = 42,
    LeaveRegion = 43,
    CustomEvent = 44,
    AnswerTYDuiLian = 45,
    CloseTYDLWnd = 46,
    TeamEnterGameplayScene = 47,
    PlayerEnterGameplayScene = 48,
    PlayerLeaveGameplayScene = 49,
    PlayerDieEnd = 50,
    FakePlayerDieEnd = 51,
    PlayerAcceptTask = 52,
    PlayerTaskStateFinish = 53,
    PlayerTaskStateActive = 54,
    GameplayTaskFailed = 55,
    GameplayTaskFinished = 56,
    GameplayTaskStepFinished = 57,
    HuoBanSwitchMode = 58,
    PlayerEnterSceneEndLoading = 59,
    TeamEnterSceneEndLoading = 60,
    EnterSceneEndLoading = 61,
    HkServerEvent = 62,
    ApplyEnterGameplay = 63,
    BWDHIsReady = 64,
    QualificationRoundEnd = 65,
    EliminationRoundEnd = 66,
    MTCTKillMonsterCntUpdate = 67,
    FindAttackPosFail = 68,
    FightPathFindFail = 69,
    GameplayPlayerResult = 70,
    SeatBroken = 71,
    BreakPhysicsObject = 72,
    BreakPhysicsObjectByUnKnown = 73,
    RebuildPhysicsObject = 74,
    NoSilverToTeleport = 75,
    TeleportPlayerViaNpc = 76,
    PlayQTESuc = 77,
    SpaceQTESuc = 78,
    NormalDance = 79,
    DancePartner = 80,
    RandomDancePartner = 81,
    PlayerSay = 82,
    Reborn = 83,
    FakePlayerReborn = 84,
    BeginConversation = 85,
    EndConversation = 86,
    BeginTrackEscort = 87,
    ExpelPlayerFromSeat = 88,
    OnReportLeafPileComplete = 89,
    PulledEnded = 90,
    Controlled = 91,
    CastSkillEvent = 92,
    PlayerEnterFight = 93,
    MonsterEnterFight = 94,
    PlayerEnterDesk = 95,
    PlayerLeaveDesk = 96,
    BeginnerHintEnd = 97,
    CastSkillRoundSuccess = 98,
    EffectMarkChange = 99,
    CastSkillShiLianSuccess = 100,
    ReportLeafPileComplete = 101,
    EnterSeatEvent = 102,
    LeaveSeatEvent = 103,
    EnemySkill = 104,
    StartTaming = 105,
    TamingSuccess = 106,
    TamingFaild = 107,
    RiderLeave = 108,
    GameplayVoteEnd = 109,
    NegativeEnergyFull = 110,
    JoinTeam = 111,
    LeaveTeam = 112,
    PlayerIdle = 113,
    PlayerEnterPlatform = 114,
    HugByPlayer = 115,
    UnHugByPlayer = 116,
    StartHuiKePlay = 117,
    EndQingLouHuike = 118,
    EndQingLouDance = 119,
    EndQingLouDaNao = 120,
    CorralOpenDoor = 121,
    AnimalDie = 122,
    AnimalKill = 123,
    AnimalHarvest = 124,
    SwordDanceScore = 125,
    TeleportByTrap = 126,
    AnimalAddMood = 127,
    AnimalRecallToCorral = 128,
    AnimalAddHealth = 129,
    ClickSwordDanceQTESuccess = 130,
    ObjectGetOnBoat = 131,
    ObjectGetOffBoat = 132,
    ZhuiMingDiceGambleEnd = 133,
    HitTarget = 134,
    PosReached = 135,
    TargetReached = 136,
    SkillCast = 137,
    Observe_OnSkillHit = 138,
    Observe_OnMoveBegan = 139,
    Observe_OnMoveEnded = 140,
    Observe_OnLeave_AirRushing = 141,
    Observe_OnLeave_Flying = 142,
    ISawLeftViewAoi = 143,
    ISawInViewAoi = 144,
    SceneSayReaded = 145,
    HpPercentChange = 146,
    PushedByPlayer = 147,
    ClientActiveMoveSuccess = 148,
    ClientActiveMoveFail = 149,
    CastFengShuiShuEvent = 150,
    SubmitQYYClue = 151,
    EncounterPlatform = 152,
    TakePicInScene = 153,
    GardenTreeCutted = 154,
    BlockChainBeginDig = 155,
    GardenResourceExchangeRefreshed = 156,
    GardenResourceExchangeConfirmed = 157,
    EnterSeatPlayEvent = 158,
    LeaveSeatPlayEvent = 159,
    DoubleQTESuccess = 160,
    DoubleQTEFail = 161,
    HeBaZiComplete = 162,
    ClientMainPlayerAddItem = 163,
    SeeFlag = 164,
    ByeFlag = 165,
    BossFirstKillTimeReturn = 166,
    GardenNearUnit = 167,
    PlayerContinueGuaJi = 168,
    BXJGameOver = 169,
    GardenSnowTDStart = 170,
    GardenSnowTDStop = 171,
    FakePlayerSkillRecover = 172,
    ServerRejectSkill = 173,
    PlayerRebornEnd = 174,
    PetTeleportScene = 175,
    BHLSSmallPlayCreate = 176,
    BHLSSmallPlayDestroy = 177,
    BHLSSmallPlayFinish = 178,
    SkillEnd = 179,
    GardenLevelStartRunning = 180,
    GardenLevelEarlyEndFight = 181,
    GardenLevelStopRunning = 182,
    MultiPickSuccess = 183,
    MovedirCallBack = 184,
    SkillCallBack = 185,
    UpdateStateOnTick = 186,
    GameplayLog = 187,
    PlayerUseItem = 188,
}

EFlowResult =
{
    Failure = 0,
    Success = 1,
}

FlowEventArgsCount =
{   
    0,  --Start
    1,  --See
    1,  --Bye
    1,  --ClientSee
    1,  --ClientBye
    2,  --Attack
    1,  --Kill
    0,  --EnterSafeRegion
    0,  --LeaveSafeRegion
    0,  --AttackObjectDie
    0,  --DummyPlayerReborn
    0,  --BossCastDangerSkill
    0,  --Tick
    0,  --MoveEnded
    0,  --AboutToMoveEnd
    1,  --MoveStopped
    0,  --MoveBegan
    1,  --PickSuccess
    0,  --TargetMove
    0,  --TaskInfoUpdate
    3,  --UpdateGameplayJob
    0,  --ThreatenUpdate
    0,  --SZQXBossAllDie
    0,  --EnterFight
    0,  --LeaveFight
    0,  --LeaveHitRecover
    0,  --EnterDash
    0,  --LeaveDash
    0,  --RecoverFromCast
    0,  --ChangePetMode
    1,  --BeginRouteEscort
    0,  --ReachLastWayPoint
    2,  --ReachWayPoint
    3,  --UnderAttack
    3,  --Die
    1,  --AlmostDie
    3,  --MonsterInClusterDestroy
    3,  --MonsterDie
    2,  --TeamVoteSuccess
    3,  --CharacterEnterRegion
    3,  --CharacterLeaveRegion
    1,  --EnterRegion
    1,  --LeaveRegion
    6,  --CustomEvent
    1,  --AnswerTYDuiLian
    0,  --CloseTYDLWnd
    1,  --TeamEnterGameplayScene
    2,  --PlayerEnterGameplayScene
    3,  --PlayerLeaveGameplayScene
    4,  --PlayerDieEnd
    4,  --FakePlayerDieEnd
    2,  --PlayerAcceptTask
    3,  --PlayerTaskStateFinish
    3,  --PlayerTaskStateActive
    2,  --GameplayTaskFailed
    1,  --GameplayTaskFinished
    2,  --GameplayTaskStepFinished
    0,  --HuoBanSwitchMode
    2,  --PlayerEnterSceneEndLoading
    1,  --TeamEnterSceneEndLoading
    0,  --EnterSceneEndLoading
    1,  --HkServerEvent
    2,  --ApplyEnterGameplay
    0,  --BWDHIsReady
    0,  --QualificationRoundEnd
    0,  --EliminationRoundEnd
    1,  --MTCTKillMonsterCntUpdate
    1,  --FindAttackPosFail
    1,  --FightPathFindFail
    2,  --GameplayPlayerResult
    1,  --SeatBroken
    3,  --BreakPhysicsObject
    2,  --BreakPhysicsObjectByUnKnown
    1,  --RebuildPhysicsObject
    1,  --NoSilverToTeleport
    5,  --TeleportPlayerViaNpc
    0,  --PlayQTESuc
    0,  --SpaceQTESuc
    2,  --NormalDance
    4,  --DancePartner
    5,  --RandomDancePartner
    3,  --PlayerSay
    0,  --Reborn
    0,  --FakePlayerReborn
    0,  --BeginConversation
    0,  --EndConversation
    2,  --BeginTrackEscort
    1,  --ExpelPlayerFromSeat
    3,  --OnReportLeafPileComplete
    0,  --PulledEnded
    0,  --Controlled
    5,  --CastSkillEvent
    1,  --PlayerEnterFight
    1,  --MonsterEnterFight
    1,  --PlayerEnterDesk
    1,  --PlayerLeaveDesk
    1,  --BeginnerHintEnd
    1,  --CastSkillRoundSuccess
    2,  --EffectMarkChange
    0,  --CastSkillShiLianSuccess
    3,  --ReportLeafPileComplete
    7,  --EnterSeatEvent
    7,  --LeaveSeatEvent
    4,  --EnemySkill
    1,  --StartTaming
    1,  --TamingSuccess
    1,  --TamingFaild
    1,  --RiderLeave
    1,  --GameplayVoteEnd
    0,  --NegativeEnergyFull
    1,  --JoinTeam
    1,  --LeaveTeam
    0,  --PlayerIdle
    1,  --PlayerEnterPlatform
    1,  --HugByPlayer
    1,  --UnHugByPlayer
    3,  --StartHuiKePlay
    1,  --EndQingLouHuike
    1,  --EndQingLouDance
    1,  --EndQingLouDaNao
    0,  --CorralOpenDoor
    0,  --AnimalDie
    1,  --AnimalKill
    1,  --AnimalHarvest
    1,  --SwordDanceScore
    0,  --TeleportByTrap
    1,  --AnimalAddMood
    0,  --AnimalRecallToCorral
    1,  --AnimalAddHealth
    3,  --ClickSwordDanceQTESuccess
    1,  --ObjectGetOnBoat
    1,  --ObjectGetOffBoat
    1,  --ZhuiMingDiceGambleEnd
    1,  --HitTarget
    0,  --PosReached
    1,  --TargetReached
    5,  --SkillCast
    3,  --Observe_OnSkillHit
    0,  --Observe_OnMoveBegan
    0,  --Observe_OnMoveEnded
    0,  --Observe_OnLeave_AirRushing
    0,  --Observe_OnLeave_Flying
    1,  --ISawLeftViewAoi
    1,  --ISawInViewAoi
    0,  --SceneSayReaded
    2,  --HpPercentChange
    1,  --PushedByPlayer
    1,  --ClientActiveMoveSuccess
    0,  --ClientActiveMoveFail
    1,  --CastFengShuiShuEvent
    4,  --SubmitQYYClue
    1,  --EncounterPlatform
    1,  --TakePicInScene
    2,  --GardenTreeCutted
    2,  --BlockChainBeginDig
    0,  --GardenResourceExchangeRefreshed
    1,  --GardenResourceExchangeConfirmed
    2,  --EnterSeatPlayEvent
    2,  --LeaveSeatPlayEvent
    0,  --DoubleQTESuccess
    0,  --DoubleQTEFail
    0,  --HeBaZiComplete
    2,  --ClientMainPlayerAddItem
    1,  --SeeFlag
    1,  --ByeFlag
    2,  --BossFirstKillTimeReturn
    2,  --GardenNearUnit
    2,  --PlayerContinueGuaJi
    0,  --BXJGameOver
    0,  --GardenSnowTDStart
    0,  --GardenSnowTDStop
    0,  --FakePlayerSkillRecover
    0,  --ServerRejectSkill
    2,  --PlayerRebornEnd
    0,  --PetTeleportScene
    0,  --BHLSSmallPlayCreate
    0,  --BHLSSmallPlayDestroy
    0,  --BHLSSmallPlayFinish
    1,  --SkillEnd
    0,  --GardenLevelStartRunning
    1,  --GardenLevelEarlyEndFight
    0,  --GardenLevelStopRunning
    3,  --MultiPickSuccess
    1,  --MovedirCallBack
    1,  --SkillCallBack
    1,  --UpdateStateOnTick
    1,  --GameplayLog
    1,  --PlayerUseItem
}

EFlowClass =
{   
    Global = 1,
    Character = 2,
    Gameplay = 3,
    ClientCharacter = 4,
    ClientMainPlayer = 5,
    Position = 6,
    ScenePosition = 7,
    Route = 8,
    TeleportWaypoint = 9,
    LiveBeh = 10,
    WanderPoint = 11,
    PlayerPairTbl = 12,
    NumberPositionTbl = 13,
    PositionNumber = 14,
    ServerBullet = 15,
    LiveNpcGossip = 16,
    SkillObject = 17,
}

FlowObjectClass =
{   
    [1] = {"Global", { }},
    [2] = {"Character", { {"leg","StopMoving"},{"arm",""},{"voice",""},{"mind",""},}},
    [3] = {"Gameplay", { {"space",""},}},
    [4] = {"ClientCharacter", { {"leg","StopMoving"},}},
    [5] = {"ClientMainPlayer", { }},
    [6] = {"Position", { }},
    [7] = {"ScenePosition", { }},
    [8] = {"Route", { }},
    [9] = {"TeleportWaypoint", { }},
    [10] = {"LiveBeh", { }},
    [11] = {"WanderPoint", { }},
    [12] = {"PlayerPairTbl", { }},
    [13] = {"NumberPositionTbl", { }},
    [14] = {"PositionNumber", { }},
    [15] = {"ServerBullet", { }},
    [16] = {"LiveNpcGossip", { }},
    [17] = {"SkillObject", { }},
}

FlowOutputPrefix = "Flowchart_" --解析生成的lua文件的前缀，如Flowchart_AI,Flowchart_Gameplay"
